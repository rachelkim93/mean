const tasks = require('./../controllers/tasks');
module.exports = function(app) {
    
    // Root Route - Get ALL Tasks
    app.get('/tasks', tasks.root);

    // Get One Task Route
    app.get('/tasks/:id', tasks.getone);

    // Add a Task Route
    app.post('/tasks', tasks.create);

    // Update a Task Route
    app.put('/tasks/:id', tasks.update);

    // Destroy Task Route
    app.delete('/tasks/destroy/:id', tasks.destroy);
};