const mongoose = require('mongoose');
const Task = mongoose.model('Task');
module.exports = {

    root: (req, res) => {
        Task.find({}, function(err, tasks){
            if(err){
                res.json({message: "error", error: err});
            } else {
                res.json({message: "Success", data: tasks});
            }
        });
    },

    getone: (req, res) => {
        Task.findById({_id: req.params.id}, (err, task) => {
            if(err){
                res.json({message: "error", error: err});
            } else {
                res.json({message: "Success", data: task});
            }
        });
    },

    create: (req, res) => {
        console.log(req.body.title);
        console.log(req.body.description);
        console.log(req.body.completed);
        let task = new Task({title: req.body.title, description: req.body.description, completed: req.body.completed});
        task.save(function(err){
            if(err){
                res.json({message: "error", error: err});
            } else {
                console.log("Added a Task!");
                res.redirect('/tasks');
            }
        });
        
    },

    update: (req, res) => {
        Task.findByIdAndUpdate({_id: req.params.id}, (err, task) => {
            if(err){
                res.json({message: "error", error: err});
            } else {
                console.log("Updated a Task!");
                res.redirect('/tasks');
            }
        });
    },

    destroy: (req, res) => {
        Task.findByIdAndRemove({_id: req.params.id}, (err) => {
            if(err){
                res.json({message: "error", error: err});
            } else {
                console.log("Deleted a Task!");
                res.redirect('/tasks');
            }
        });
    }

};